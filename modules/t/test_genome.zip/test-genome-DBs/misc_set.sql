# MySQL dump 8.16
#
# Host: ecs4    Database: _test_db_homo_sapiens_core_gp1_23_3_10017
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'misc_set'
#

CREATE TABLE misc_set (
  misc_set_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(25) collate latin1_bin NOT NULL default '',
  name varchar(255) collate latin1_bin NOT NULL default '',
  description text collate latin1_bin NOT NULL,
  max_length int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (misc_set_id),
  UNIQUE KEY c (code)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
