# MySQL dump 8.16
#
# Host: ecs4    Database: _test_db_homo_sapiens_core_gp1_23_3_10017
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'seq_region'
#

CREATE TABLE seq_region (
  seq_region_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40) collate latin1_bin default NULL,
  coord_system_id int(10) default NULL,
  length int(10) default NULL,
  PRIMARY KEY  (seq_region_id),
  UNIQUE KEY coord_system_id (coord_system_id,name),
  KEY name_idx (name)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
