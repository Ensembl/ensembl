-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `analysis_description`
--

CREATE TABLE analysis_description (
  analysis_id int(10) unsigned NOT NULL default '0',
  description text,
  display_label varchar(255) default NULL,
  KEY analysis_idx (analysis_id)
) TYPE=MyISAM;
