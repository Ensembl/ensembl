# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'analysis_description'
#

CREATE TABLE analysis_description (
  analysis_id int(10) unsigned DEFAULT '0' NOT NULL,
  description text,
  display_label varchar(255),
  KEY analysis_idx (analysis_id)
);
