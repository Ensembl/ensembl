# MySQL dump 8.16
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'karyotype'
#

CREATE TABLE karyotype (
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) DEFAULT '0' NOT NULL,
  seq_region_end int(10) DEFAULT '0' NOT NULL,
  band varchar(40) DEFAULT '' NOT NULL,
  stain varchar(40) DEFAULT '' NOT NULL,
  PRIMARY KEY (seq_region_id,band)
);
