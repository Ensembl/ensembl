# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'transcript'
#

CREATE TABLE transcript (
  transcript_id int(10) unsigned NOT NULL auto_increment,
  gene_id int(10) unsigned DEFAULT '0' NOT NULL,
  translation_id int(10) unsigned DEFAULT '0' NOT NULL,
  exon_count int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (transcript_id),
  KEY gene_index (gene_id),
  KEY translation_index (translation_id)
);
