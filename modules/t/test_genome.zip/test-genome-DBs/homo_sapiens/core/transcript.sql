-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `transcript`
--

CREATE TABLE transcript (
  transcript_id int(10) unsigned NOT NULL auto_increment,
  gene_id int(10) unsigned NOT NULL default '0',
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) unsigned NOT NULL default '0',
  seq_region_end int(10) unsigned NOT NULL default '0',
  seq_region_strand tinyint(2) NOT NULL default '0',
  display_xref_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (transcript_id),
  KEY seq_region_idx (seq_region_id,seq_region_start),
  KEY gene_index (gene_id),
  KEY xref_id_index (display_xref_id)
) TYPE=MyISAM;
