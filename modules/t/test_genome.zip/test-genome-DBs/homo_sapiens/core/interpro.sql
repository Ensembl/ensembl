-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `interpro`
--

CREATE TABLE interpro (
  interpro_ac varchar(40) NOT NULL default '',
  id varchar(40) NOT NULL default '',
  UNIQUE KEY interpro_ac (interpro_ac,id),
  KEY id (id)
) TYPE=MyISAM;
