# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'interpro'
#

CREATE TABLE interpro (
  interpro_ac varchar(40) DEFAULT '' NOT NULL,
  id varchar(40) DEFAULT '' NOT NULL,
  UNIQUE interpro_ac (interpro_ac,id),
  KEY id (id)
);
