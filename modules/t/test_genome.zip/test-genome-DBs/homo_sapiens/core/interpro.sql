-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'interpro'
--

CREATE TABLE interpro (
  interpro_ac varchar(40) NOT NULL default '',
  id varchar(40) NOT NULL default '',
  KEY interpro_ac (interpro_ac),
  KEY id (id)
) TYPE=MyISAM;
