# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_ens36_map
#--------------------------------------------------------
# Server version	4.1.12-log

#
# Table structure for table 'regulatory_feature'
#

CREATE TABLE regulatory_feature (
  regulatory_feature_id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  seq_region_id int(11) NOT NULL default '0',
  seq_region_start int(11) NOT NULL default '0',
  seq_region_end int(11) NOT NULL default '0',
  seq_region_strand tinyint(4) NOT NULL default '0',
  analysis_id int(11) NOT NULL default '0',
  regulatory_factor_id int(11) default NULL,
  PRIMARY KEY  (regulatory_feature_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
