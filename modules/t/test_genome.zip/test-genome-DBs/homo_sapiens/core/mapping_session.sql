# MySQL dump 8.16
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'mapping_session'
#

CREATE TABLE mapping_session (
  mapping_session_id int(11) NOT NULL auto_increment,
  old_db_name varchar(80) DEFAULT '' NOT NULL,
  new_db_name varchar(80) DEFAULT '' NOT NULL,
  created timestamp(14),
  PRIMARY KEY (mapping_session_id)
);
