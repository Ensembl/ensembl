-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'mapping_session'
--

CREATE TABLE mapping_session (
  mapping_session_id int(11) NOT NULL auto_increment,
  old_db_name varchar(80) NOT NULL default '',
  new_db_name varchar(80) NOT NULL default '',
  created timestamp(14) NOT NULL,
  PRIMARY KEY  (mapping_session_id)
) TYPE=MyISAM;
