-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `mapping_session`
--

CREATE TABLE mapping_session (
  mapping_session_id int(11) NOT NULL auto_increment,
  old_db_name varchar(80) NOT NULL default '',
  new_db_name varchar(80) NOT NULL default '',
  created timestamp(14) NOT NULL,
  PRIMARY KEY  (mapping_session_id)
) TYPE=MyISAM;
