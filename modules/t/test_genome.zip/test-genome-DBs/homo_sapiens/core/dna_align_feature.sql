-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'dna_align_feature'
--

CREATE TABLE dna_align_feature (
  dna_align_feature_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) unsigned NOT NULL default '0',
  seq_region_end int(10) unsigned NOT NULL default '0',
  seq_region_strand tinyint(1) NOT NULL default '0',
  hit_start int(11) NOT NULL default '0',
  hit_end int(11) NOT NULL default '0',
  hit_strand tinyint(1) NOT NULL default '0',
  hit_name varchar(40) NOT NULL default '',
  analysis_id int(10) unsigned NOT NULL default '0',
  score double default NULL,
  evalue double default NULL,
  perc_ident float default NULL,
  cigar_line text,
  PRIMARY KEY  (dna_align_feature_id),
  KEY hit_idx (hit_name),
  KEY dfg_idx (seq_region_id),
  KEY ana_idx (analysis_id)
) TYPE=MyISAM MAX_ROWS=100000000 AVG_ROW_LENGTH=80;
