# MySQL dump 8.10
#
# Host: localhost    Database: glenn_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'repeat_feature'
#

CREATE TABLE repeat_feature (
  repeat_feature_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_end int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_strand tinyint(1) DEFAULT '1' NOT NULL,
  repeat_start int(10) DEFAULT '0' NOT NULL,
  repeat_end int(10) DEFAULT '0' NOT NULL,
  repeat_consensus_id int(10) unsigned DEFAULT '0' NOT NULL,
  analysis_id int(10) unsigned DEFAULT '0' NOT NULL,
  score double,
  PRIMARY KEY (repeat_feature_id),
  KEY seq_region_idx (seq_region_id),
  KEY repeat_idx (repeat_consensus_id),
  KEY analysis_idx (analysis_id)
);
