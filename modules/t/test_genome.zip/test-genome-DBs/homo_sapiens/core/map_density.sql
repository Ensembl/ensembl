# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'map_density'
#

CREATE TABLE map_density (
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) DEFAULT '0' NOT NULL,
  seq_region_end int(10) DEFAULT '0' NOT NULL,
  type varchar(20) DEFAULT '' NOT NULL,
  value int(10) DEFAULT '0' NOT NULL,
  PRIMARY KEY (type,seq_region_id,seq_region_start)
);
