-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'map_density'
--

CREATE TABLE map_density (
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) NOT NULL default '0',
  seq_region_end int(10) NOT NULL default '0',
  type varchar(20) NOT NULL default '',
  value int(10) NOT NULL default '0',
  PRIMARY KEY  (type,seq_region_id,seq_region_start)
) TYPE=MyISAM;
