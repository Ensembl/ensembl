-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `marker_map_location`
--

CREATE TABLE marker_map_location (
  marker_id int(10) unsigned NOT NULL default '0',
  map_id int(10) unsigned NOT NULL default '0',
  chromosome_name varchar(15) NOT NULL default '',
  marker_synonym_id int(10) unsigned NOT NULL default '0',
  position varchar(15) NOT NULL default '',
  lod_score double default NULL,
  PRIMARY KEY  (marker_id,map_id),
  KEY map_idx (map_id,chromosome_name,position)
) TYPE=MyISAM;
