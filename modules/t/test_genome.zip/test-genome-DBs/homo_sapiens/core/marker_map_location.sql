# MySQL dump 8.10
#
# Host: ecs1c    Database: mcvicker_markers
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'marker_map_location'
#

CREATE TABLE marker_map_location (
  marker_id int(10) unsigned DEFAULT '0' NOT NULL,
  map_id int(10) unsigned DEFAULT '0' NOT NULL,
  chromosome_id int(10) unsigned DEFAULT '0' NOT NULL,
  marker_synonym_id int(10) unsigned DEFAULT '0' NOT NULL,
  position varchar(15) DEFAULT '' NOT NULL,
  lod_score double,
  PRIMARY KEY (marker_id,map_id),
  KEY map_idx (map_id,chromosome_id,position)
);
