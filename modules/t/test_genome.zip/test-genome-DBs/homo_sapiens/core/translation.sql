# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_2_6_175857
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'translation'
#

CREATE TABLE translation (
  translation_id int(10) unsigned NOT NULL auto_increment,
  seq_start int(10) DEFAULT '0' NOT NULL,
  start_exon_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_end int(10) DEFAULT '0' NOT NULL,
  end_exon_id int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (translation_id)
);
