# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_28_5_115918
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'exon'
#

CREATE TABLE exon (
  exon_id int(10) unsigned NOT NULL auto_increment,
  contig_id int(10) unsigned DEFAULT '0' NOT NULL,
  contig_start int(10) unsigned DEFAULT '0' NOT NULL,
  contig_end int(10) unsigned DEFAULT '0' NOT NULL,
  contig_strand tinyint(2) DEFAULT '0' NOT NULL,
  phase tinyint(2) DEFAULT '0' NOT NULL,
  end_phase tinyint(2) DEFAULT '0' NOT NULL,
  sticky_rank tinyint(4) DEFAULT '1' NOT NULL,
  PRIMARY KEY (exon_id,sticky_rank),
  KEY contig_idx (contig_id,contig_start)
);
