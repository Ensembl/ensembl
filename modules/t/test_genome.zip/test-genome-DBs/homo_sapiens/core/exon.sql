# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'exon'
#

CREATE TABLE exon (
  exon_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_end int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_strand tinyint(2) DEFAULT '0' NOT NULL,
  phase tinyint(2) DEFAULT '0' NOT NULL,
  end_phase tinyint(2) DEFAULT '0' NOT NULL,
  PRIMARY KEY (exon_id),
  KEY seq_region_idx (seq_region_id,seq_region_start)
);
