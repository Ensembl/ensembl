# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'exon_stable_id'
#

CREATE TABLE exon_stable_id (
  exon_id int(10) unsigned DEFAULT '0' NOT NULL,
  stable_id varchar(40) DEFAULT '' NOT NULL,
  version int(10) DEFAULT '1' NOT NULL,
  created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  modified datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY (exon_id),
  UNIQUE stable_id (stable_id,version)
);
