CREATE TABLE regulatory_factor_coding (
  regulatory_factor_id  INT NOT NULL,
  transcript_id         INT,         
  gene_id         	INT,         
  KEY transcript_idx (transcript_id),
  KEY gene_idx (gene_id),
  KEY regulatory_factor_idx (regulatory_factor_id)
) COLLATE=latin1_swedish_ci TYPE=MyISAM;