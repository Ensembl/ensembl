# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'mapfrag_mapset'
#

CREATE TABLE mapfrag_mapset (
  mapfrag_id int(10) unsigned DEFAULT '0' NOT NULL,
  mapset_id smallint(5) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (mapset_id,mapfrag_id)
);
