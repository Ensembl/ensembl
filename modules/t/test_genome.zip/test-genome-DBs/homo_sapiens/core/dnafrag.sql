# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dnafrag'
#

CREATE TABLE dnafrag (
  dnafrag_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  dnafrag_type enum('RawContig','Chromosome'),
  PRIMARY KEY (dnafrag_id),
  UNIQUE name (name)
);
