# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dnafrag'
#

CREATE TABLE dnafrag (
  dnafrag_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  dnafrag_type varchar(40),
  PRIMARY KEY (dnafrag_id),
  UNIQUE name (name)
);
