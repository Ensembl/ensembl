# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_30
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'regulatory_feature_object'
#

CREATE TABLE regulatory_feature_object (
  regulatory_feature_id int(11) NOT NULL default '0',
  ensembl_object_type enum('Transcript','Translation','Gene') collate latin1_bin NOT NULL default 'Transcript',
  ensembl_object_id int(11) NOT NULL default '0',
  KEY regulatory_feature_idx (regulatory_feature_id),
  KEY ensembl_object_idx (ensembl_object_type,ensembl_object_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
