# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'gene_archive'
#

CREATE TABLE gene_archive (
  gene_stable_id varchar(40) DEFAULT '' NOT NULL,
  gene_version smallint(6) DEFAULT '0' NOT NULL,
  transcript_stable_id varchar(40) DEFAULT '' NOT NULL,
  transcript_version smallint(6) DEFAULT '0' NOT NULL,
  translation_stable_id varchar(40) DEFAULT '' NOT NULL,
  translation_version smallint(6) DEFAULT '0' NOT NULL,
  mapping_session_id int(11) DEFAULT '0' NOT NULL,
  KEY gene_idx (gene_stable_id,gene_version),
  KEY transcript_idx (transcript_stable_id,transcript_version)
);
