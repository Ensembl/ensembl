# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_28_5_115918
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'gene_archive'
#

CREATE TABLE gene_archive (
  gene_stable_id varchar(40) DEFAULT '' NOT NULL,
  gene_version smallint(6) DEFAULT '0' NOT NULL,
  transcript_stable_id varchar(40) DEFAULT '' NOT NULL,
  transcript_version smallint(6) DEFAULT '0' NOT NULL,
  translation_stable_id varchar(40) DEFAULT '' NOT NULL,
  translation_version smallint(6) DEFAULT '0' NOT NULL,
  mapping_session_id int(11) DEFAULT '0' NOT NULL,
  KEY gene_idx (gene_stable_id,gene_version),
  KEY transcript_idx (transcript_stable_id,transcript_version)
);
