# MySQL dump 8.16
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'gene'
#

CREATE TABLE gene (
  gene_id int(10) unsigned NOT NULL auto_increment,
  type varchar(40) DEFAULT '' NOT NULL,
  analysis_id int(11),
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_end int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_strand tinyint(2) DEFAULT '0' NOT NULL,
  display_xref_id int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (gene_id),
  KEY xref_id_index (display_xref_id)
);
