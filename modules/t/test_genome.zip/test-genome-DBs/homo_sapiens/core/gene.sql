CREATE TABLE `gene` (
  `gene_id` int(10) unsigned NOT NULL auto_increment,
  `biotype` varchar(40) collate latin1_bin NOT NULL default 'protein_coding',
  `analysis_id` int(11) default NULL,
  `seq_region_id` int(10) unsigned NOT NULL default '0',
  `seq_region_start` int(10) unsigned NOT NULL default '0',
  `seq_region_end` int(10) unsigned NOT NULL default '0',
  `seq_region_strand` tinyint(2) NOT NULL default '0',
  `display_xref_id` int(10) unsigned NOT NULL default '0',
  `source` varchar(20) collate latin1_bin NOT NULL default 'ensembl',
  `status` enum('KNOWN','NOVEL','PUTATIVE','PREDICTED') collate latin1_bin default 'NOVEL',
  `description` text collate latin1_bin,
  PRIMARY KEY  (`gene_id`),
  KEY `seq_region_idx` (`seq_region_id`,`seq_region_start`),
  KEY `xref_id_index` (`display_xref_id`),
  KEY `analysis_idx` (`analysis_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

