-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'gene'
--

CREATE TABLE gene (
  gene_id int(10) unsigned NOT NULL auto_increment,
  type varchar(40) NOT NULL default '',
  analysis_id int(11) default NULL,
  seq_region_id int(10) unsigned NOT NULL default '0',
  seq_region_start int(10) unsigned NOT NULL default '0',
  seq_region_end int(10) unsigned NOT NULL default '0',
  seq_region_strand tinyint(2) NOT NULL default '0',
  display_xref_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (gene_id),
  KEY xref_id_index (display_xref_id)
) TYPE=MyISAM;
