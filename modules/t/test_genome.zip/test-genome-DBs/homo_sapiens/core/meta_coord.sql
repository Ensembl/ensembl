-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `meta_coord`
--

CREATE TABLE meta_coord (
  table_name varchar(40) default NULL,
  coord_system_id int(11) default NULL,
  max_length int(11) default NULL,
  UNIQUE KEY table_name (table_name,coord_system_id)
) TYPE=MyISAM;
