# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_ens36_map
#--------------------------------------------------------
# Server version	4.1.12-log

#
# Table structure for table 'meta_coord'
#

CREATE TABLE meta_coord (
  table_name varchar(40) collate latin1_bin default NULL,
  coord_system_id int(11) default NULL,
  max_length int(11) default NULL,
  UNIQUE KEY table_name (table_name,coord_system_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
