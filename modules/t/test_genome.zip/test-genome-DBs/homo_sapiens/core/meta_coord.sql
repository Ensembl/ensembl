# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'meta_coord'
#

CREATE TABLE meta_coord (
  table_name varchar(40),
  coord_system_id int(11)
);
