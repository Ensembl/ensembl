-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'meta_coord'
--

CREATE TABLE meta_coord (
  table_name varchar(40) default NULL,
  coord_system_id int(11) default NULL
) TYPE=MyISAM;
