# MySQL dump 8.16
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'xref'
#

CREATE TABLE xref (
  xref_id int(10) unsigned NOT NULL auto_increment,
  external_db_id int(11) DEFAULT '0' NOT NULL,
  dbprimary_acc varchar(40) DEFAULT '' NOT NULL,
  display_label varchar(40) DEFAULT '' NOT NULL,
  version varchar(10) DEFAULT '' NOT NULL,
  description varchar(255),
  PRIMARY KEY (xref_id),
  UNIQUE id_index (dbprimary_acc,external_db_id),
  KEY display_index (display_label)
);
