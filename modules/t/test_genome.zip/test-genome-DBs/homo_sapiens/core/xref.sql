# MySQL dump 8.16
#
# Host: ecs2    Database: homo_sapiens_core_24_34e
#--------------------------------------------------------
# Server version	4.0.18-standard-log

#
# Table structure for table 'xref'
#

CREATE TABLE xref (
  xref_id int(10) unsigned NOT NULL auto_increment,
  external_db_id int(11) NOT NULL default '0',
  dbprimary_acc varchar(40) NOT NULL default '',
  display_label varchar(40) NOT NULL default '',
  version varchar(10) NOT NULL default '',
  description varchar(255) default NULL,
  PRIMARY KEY  (xref_id),
  UNIQUE KEY id_index (dbprimary_acc,external_db_id),
  KEY display_index (display_label)
) TYPE=MyISAM;
