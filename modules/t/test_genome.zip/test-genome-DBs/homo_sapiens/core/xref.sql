CREATE TABLE xref (

   xref_id 		      INT unsigned not null auto_increment,
   external_db_id             int not null,
   dbprimary_acc              VARCHAR(40) not null,
   display_label              VARCHAR(40) not null,
   version                    VARCHAR(10) DEFAULT '' NOT NULL,
   description                VARCHAR(255),

   PRIMARY KEY( xref_id ),
   UNIQUE KEY id_index( dbprimary_acc, external_db_id ),
   KEY display_index ( display_label )

);
