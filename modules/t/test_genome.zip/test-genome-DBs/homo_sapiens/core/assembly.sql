# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_2_6_175857
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'assembly'
#

CREATE TABLE assembly (
  chromosome_id int(10) unsigned DEFAULT '0' NOT NULL,
  chr_start int(10) DEFAULT '0' NOT NULL,
  chr_end int(10) DEFAULT '0' NOT NULL,
  superctg_name varchar(20) DEFAULT '' NOT NULL,
  superctg_start int(10) DEFAULT '0' NOT NULL,
  superctg_end int(10) DEFAULT '0' NOT NULL,
  superctg_ori tinyint(2) DEFAULT '0' NOT NULL,
  contig_id int(10) unsigned DEFAULT '0' NOT NULL,
  contig_start int(10) DEFAULT '0' NOT NULL,
  contig_end int(10) DEFAULT '0' NOT NULL,
  contig_ori tinyint(4) DEFAULT '0' NOT NULL,
  type varchar(20) DEFAULT '' NOT NULL,
  PRIMARY KEY (contig_id,type),
  KEY superctg_name (superctg_name,superctg_start),
  KEY chromosome_id (chromosome_id,chr_start)
);
