# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'assembly'
#

CREATE TABLE assembly (
  asm_seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  cmp_seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  asm_start int(10) DEFAULT '0' NOT NULL,
  asm_end int(10) DEFAULT '0' NOT NULL,
  cmp_start int(10) DEFAULT '0' NOT NULL,
  cmp_end int(10) DEFAULT '0' NOT NULL,
  ori tinyint(4) DEFAULT '0' NOT NULL,
  KEY cmp_seq_region_id (cmp_seq_region_id),
  KEY asm_seq_region_id (asm_seq_region_id,asm_start)
);
