# MySQL dump 8.10
#
# Host: localhost    Database: glenn_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'analysis'
#

CREATE TABLE analysis (
  analysis_id int(10) unsigned NOT NULL auto_increment,
  created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  logic_name varchar(40) DEFAULT '' NOT NULL,
  db varchar(120),
  db_version varchar(40),
  db_file varchar(120),
  program varchar(80),
  program_version varchar(40),
  program_file varchar(80),
  parameters varchar(255),
  module varchar(80),
  module_version varchar(40),
  gff_source varchar(40),
  gff_feature varchar(40),
  PRIMARY KEY (analysis_id),
  KEY logic_name_idx (logic_name)
);
