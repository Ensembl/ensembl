# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_30
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'dnac'
#

CREATE TABLE dnac (
  seq_region_id int(10) unsigned NOT NULL default '0',
  sequence mediumblob NOT NULL,
  n_line text collate latin1_bin,
  PRIMARY KEY  (seq_region_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
