# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_core
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dnac'
#

CREATE TABLE dnac (
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  sequence mediumblob DEFAULT '' NOT NULL,
  n_line text,
  PRIMARY KEY (seq_region_id)
);
