-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'dnac'
--

CREATE TABLE dnac (
  seq_region_id int(10) unsigned NOT NULL default '0',
  sequence mediumblob NOT NULL,
  n_line text,
  PRIMARY KEY  (seq_region_id)
) TYPE=MyISAM MAX_ROWS=750000 AVG_ROW_LENGTH=19000;
