# MySQL dump 8.10
#
# Host: localhost    Database: glenn_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dnac'
#

CREATE TABLE dnac (
  dna_id int(10) unsigned NOT NULL auto_increment,
  sequence mediumblob DEFAULT '' NOT NULL,
  created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  n_line text,
  PRIMARY KEY (dna_id)
);
