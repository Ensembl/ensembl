# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dnac'
#

CREATE TABLE dnac (
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  sequence mediumblob DEFAULT '' NOT NULL,
  created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  n_line text,
  PRIMARY KEY (seq_region_id)
);
