# MySQL dump 8.16
#
# Host: ecs2d    Database: homo_sapiens_core_16_33
#--------------------------------------------------------
# Server version	3.23.49

#
# Table structure for table 'dnac'
#

CREATE TABLE dnac (
  dna_id int(10) unsigned NOT NULL auto_increment,
  sequence mediumblob NOT NULL,
  created datetime NOT NULL default '0000-00-00 00:00:00',
  n_line text,
  PRIMARY KEY  (dna_id)
) TYPE=MyISAM MAX_ROWS=750000 AVG_ROW_LENGTH=19000;
