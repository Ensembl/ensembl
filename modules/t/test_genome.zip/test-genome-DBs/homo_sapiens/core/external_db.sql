# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_core
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'external_db'
#

CREATE TABLE external_db (
  external_db_id int(11) DEFAULT '0' NOT NULL,
  db_name varchar(100) DEFAULT '' NOT NULL,
  release varchar(40) DEFAULT '' NOT NULL,
  status enum('KNOWNXREF','KNOWN','XREF','PRED','ORTH','PSEUDO') DEFAULT 'KNOWNXREF' NOT NULL,
  PRIMARY KEY (external_db_id)
);
