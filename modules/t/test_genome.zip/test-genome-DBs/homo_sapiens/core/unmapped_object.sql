CREATE TABLE `unmapped_object` (

  `unmapped_object_id`    INT,
  `type`                  ENUM("xref", "cDNA", "Marker"),
  `analysis_id`           INT(10) UNSIGNED NOT NULL,
  `external_db_id`        INT,
  `identifier`            VARCHAR(255) NOT NULL,
  `unmapped_reason_id`    SMALLINT(5) UNSIGNED NOT NULL,
  `score`                 DOUBLE,
  PRIMARY KEY            (`unmapped_object_id`),
  KEY                    id_idx(`identifier`),
  KEY                    anal_idx(`analysis_id`),
  KEY                    anal_exdb_idx(`analysis_id`,`external_db_id`)
   
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;