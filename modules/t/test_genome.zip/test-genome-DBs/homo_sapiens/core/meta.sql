# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_core
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'meta'
#

CREATE TABLE meta (
  meta_id int(11) NOT NULL auto_increment,
  meta_key varchar(40) DEFAULT '' NOT NULL,
  meta_value varchar(255) DEFAULT '' NOT NULL,
  PRIMARY KEY (meta_id),
  KEY meta_key_index (meta_key),
  KEY meta_value_index (meta_value)
);
