# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'identity_xref'
#

CREATE TABLE identity_xref (
  object_xref_id int(10) unsigned DEFAULT '0' NOT NULL,
  query_identity int(5),
  target_identity int(5),
  PRIMARY KEY (object_xref_id)
);
