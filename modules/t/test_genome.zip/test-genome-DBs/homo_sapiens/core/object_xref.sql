# MySQL dump 8.10
#
# Host: localhost    Database: glenn_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'object_xref'
#

CREATE TABLE object_xref (
  object_xref_id int(11) NOT NULL auto_increment,
  ensembl_id int(10) unsigned DEFAULT '0' NOT NULL,
  ensembl_object_type enum('RawContig','Transcript','Gene','Translation') DEFAULT 'RawContig' NOT NULL,
  xref_id int(10) unsigned DEFAULT '0' NOT NULL,
  UNIQUE ensembl_object_type (ensembl_object_type,ensembl_id,xref_id),
  KEY xref_index (object_xref_id,xref_id,ensembl_object_type,ensembl_id)
);
