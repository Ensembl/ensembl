# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'external_synonym'
#

CREATE TABLE external_synonym (
  xref_id int(10) unsigned DEFAULT '0' NOT NULL,
  synonym varchar(40) DEFAULT '' NOT NULL,
  PRIMARY KEY (xref_id,synonym),
  KEY name_index (synonym)
);
