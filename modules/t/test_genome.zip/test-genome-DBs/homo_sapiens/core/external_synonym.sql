-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'external_synonym'
--

CREATE TABLE external_synonym (
  xref_id int(10) unsigned NOT NULL default '0',
  synonym varchar(40) NOT NULL default '',
  PRIMARY KEY  (xref_id,synonym),
  KEY name_index (synonym)
) TYPE=MyISAM;
