# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'coord_system'
#

CREATE TABLE coord_system (
  coord_system_id int(11) NOT NULL auto_increment,
  name varchar(40),
  version varchar(40),
  attrib set('default_version','sequence_level'),
  rank  int not null,
  UNIQUE name (name,version),
  UNIQUE (rank),
  PRIMARY KEY (coord_system_id)
);
