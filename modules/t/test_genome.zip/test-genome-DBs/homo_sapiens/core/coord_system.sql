# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'coord_system'
#

CREATE TABLE coord_system (
  coord_system_id int(11) NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  version varchar(40),
  rank int(11) DEFAULT '0' NOT NULL,
  attrib set('default_version','sequence_level'),
  UNIQUE name (name,version),
  UNIQUE rank (rank),
  PRIMARY KEY (coord_system_id)
);
