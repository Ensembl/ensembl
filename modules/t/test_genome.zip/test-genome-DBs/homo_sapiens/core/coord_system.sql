-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'coord_system'
--

CREATE TABLE coord_system (
  coord_system_id int(11) NOT NULL auto_increment,
  name varchar(40) default NULL,
  version varchar(40) default NULL,
  attrib set('top_level','default_version','sequence_level') default NULL,
  PRIMARY KEY  (coord_system_id),
  UNIQUE KEY name (name,version)
) TYPE=MyISAM;
