# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'marker_synonym'
#

CREATE TABLE marker_synonym (
  marker_synonym_id int(10) unsigned NOT NULL auto_increment,
  marker_id int(10) unsigned DEFAULT '0' NOT NULL,
  source varchar(20),
  name varchar(30),
  PRIMARY KEY (marker_synonym_id),
  KEY marker_synonym_idx (marker_synonym_id,name),
  KEY marker_idx (marker_id)
);
