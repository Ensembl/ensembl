# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'seq_region_annotation'
#

CREATE TABLE seq_region_annotation (
  seq_region_id int(11),
  value varchar(40),
  attrib varchar(40),
  KEY annotation_idx (seq_region_id)
);
