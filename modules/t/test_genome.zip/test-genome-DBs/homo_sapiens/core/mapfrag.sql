# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_28_5_115918
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'mapfrag'
#

CREATE TABLE mapfrag (
  mapfrag_id int(10) unsigned NOT NULL auto_increment,
  type enum('clone','superctg','assembly_contig','band','chr','gap') DEFAULT 'clone' NOT NULL,
  dnafrag_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_start int(10) unsigned DEFAULT '0' NOT NULL,
  seq_end int(10) unsigned DEFAULT '0' NOT NULL,
  orientation tinyint(4) DEFAULT '0' NOT NULL,
  name varchar(40) DEFAULT '' NOT NULL,
  PRIMARY KEY (mapfrag_id),
  KEY name_idx (name),
  KEY m (dnafrag_id,seq_start)
);
