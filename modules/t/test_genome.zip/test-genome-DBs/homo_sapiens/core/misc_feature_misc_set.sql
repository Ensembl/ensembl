# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'misc_feature_misc_set'
#

CREATE TABLE misc_feature_misc_set (
  misc_feature_id int(10) unsigned DEFAULT '0' NOT NULL,
  misc_set_id smallint(5) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (misc_feature_id,misc_set_id),
  KEY reverse_idx (misc_set_id,misc_feature_id)
);
