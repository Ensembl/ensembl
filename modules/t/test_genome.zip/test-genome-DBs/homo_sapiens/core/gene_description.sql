-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'gene_description'
--

CREATE TABLE gene_description (
  gene_id int(10) unsigned NOT NULL default '0',
  description text,
  PRIMARY KEY  (gene_id)
) TYPE=MyISAM;
