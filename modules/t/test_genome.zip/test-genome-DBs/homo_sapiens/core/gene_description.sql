# MySQL dump 8.10
#
# Host: localhost    Database: glenn_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'gene_description'
#

CREATE TABLE gene_description (
  gene_id int(10) unsigned DEFAULT '0' NOT NULL,
  description text,
  PRIMARY KEY (gene_id)
);
