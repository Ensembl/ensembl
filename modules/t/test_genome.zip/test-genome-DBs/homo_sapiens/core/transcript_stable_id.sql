# MySQL dump 8.16
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'transcript_stable_id'
#

CREATE TABLE transcript_stable_id (
  transcript_id int(10) unsigned DEFAULT '0' NOT NULL,
  stable_id varchar(40) DEFAULT '' NOT NULL,
  version int(10),
  PRIMARY KEY (transcript_id),
  UNIQUE stable_id (stable_id,version)
);
