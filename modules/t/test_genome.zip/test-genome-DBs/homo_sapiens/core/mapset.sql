# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'mapset'
#

CREATE TABLE mapset (
  mapset_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(15) DEFAULT '' NOT NULL,
  name varchar(255) DEFAULT '' NOT NULL,
  description text DEFAULT '' NOT NULL,
  max_length int(10) unsigned DEFAULT '0' NOT NULL,
  PRIMARY KEY (mapset_id),
  UNIQUE c (code)
);
