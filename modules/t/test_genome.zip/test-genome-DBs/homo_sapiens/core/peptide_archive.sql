-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'peptide_archive'
--

CREATE TABLE peptide_archive (
  translation_stable_id varchar(40) NOT NULL default '',
  translation_version smallint(6) NOT NULL default '0',
  peptide_seq mediumtext NOT NULL,
  PRIMARY KEY  (translation_stable_id,translation_version)
) TYPE=MyISAM;
