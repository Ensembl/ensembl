# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_28_5_115918
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'peptide_archive'
#

CREATE TABLE peptide_archive (
  translation_stable_id varchar(40) DEFAULT '' NOT NULL,
  translation_version smallint(6) DEFAULT '0' NOT NULL,
  peptide_seq mediumtext DEFAULT '' NOT NULL,
  PRIMARY KEY (translation_stable_id,translation_version)
);
