# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'qtl'
#

CREATE TABLE qtl (
  qtl_id int(10) unsigned NOT NULL auto_increment,
  trait varchar(255) DEFAULT '' NOT NULL,
  lod_score float,
  flank_marker_id_1 int(11),
  flank_marker_id_2 int(11),
  peak_marker_id int(11),
  PRIMARY KEY (qtl_id),
  KEY trait_idx (trait)
);
