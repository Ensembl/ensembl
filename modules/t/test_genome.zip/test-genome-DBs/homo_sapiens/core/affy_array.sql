-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `affy_array`
--

CREATE TABLE affy_array (
  affy_array_id int(11) NOT NULL auto_increment,
  parent_array_id int(11) default NULL,
  probe_setsize tinyint(4) NOT NULL default '0',
  name varchar(40) NOT NULL default '',
  PRIMARY KEY  (affy_array_id)
) TYPE=MyISAM;
