# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'affy_array'
#

CREATE TABLE affy_array (
  affy_array_id int(11) NOT NULL auto_increment,
  parent_array_id int(11),
  probe_setsize tinyint(4) DEFAULT '0' NOT NULL,
  name varchar(40) DEFAULT '' NOT NULL,
  PRIMARY KEY (affy_array_id)
);
