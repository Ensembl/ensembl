# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_30
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'peptide_regulatory_feature'
#

CREATE TABLE peptide_regulatory_feature (
  translation_id int(11) NOT NULL default '0',
  regulatory_feature_id int(11) NOT NULL default '0',
  KEY translation_idx (translation_id),
  KEY regulatory_feature_idx (regulatory_feature_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
