# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_2_6_175857
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'marker_feature'
#

CREATE TABLE marker_feature (
  marker_feature_id int(10) unsigned NOT NULL auto_increment,
  marker_id int(10) unsigned DEFAULT '0' NOT NULL,
  contig_id int(10) unsigned DEFAULT '0' NOT NULL,
  contig_start int(10) unsigned DEFAULT '0' NOT NULL,
  contig_end int(10) unsigned DEFAULT '0' NOT NULL,
  analysis_id int(10) unsigned DEFAULT '0' NOT NULL,
  map_weight int(10) unsigned,
  PRIMARY KEY (marker_feature_id),
  KEY contig_idx (contig_id,contig_start)
);
