# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'marker_feature'
#

CREATE TABLE marker_feature (
  marker_feature_id int(10) unsigned NOT NULL auto_increment,
  marker_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_end int(10) unsigned DEFAULT '0' NOT NULL,
  analysis_id int(10) unsigned DEFAULT '0' NOT NULL,
  map_weight int(10) unsigned,
  PRIMARY KEY (marker_feature_id),
  KEY seq_region_idx (seq_region_id)
);
