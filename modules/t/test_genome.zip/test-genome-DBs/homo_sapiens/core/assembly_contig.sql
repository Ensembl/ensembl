# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_28_5_115918
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'assembly_contig'
#

CREATE TABLE assembly_contig (
  assembly_contig_id int(10) unsigned NOT NULL auto_increment,
  assembly_contig_name varchar(20) DEFAULT '' NOT NULL,
  assembly_contig_chr_name varchar(20) DEFAULT '' NOT NULL,
  assembly_contig_start int(10) DEFAULT '0' NOT NULL,
  assembly_contig_end int(10) DEFAULT '0' NOT NULL,
  assembly_contig_chr_start int(10) DEFAULT '0' NOT NULL,
  assembly_contig_chr_end int(10) DEFAULT '0' NOT NULL,
  assembly_contig_orientation tinyint(2) DEFAULT '0' NOT NULL,
  assembly_contig_type varchar(20) DEFAULT '' NOT NULL,
  PRIMARY KEY (assembly_contig_id),
  KEY assembly_contig_name (assembly_contig_name,assembly_contig_type),
  KEY assembly_contig_chr_name (assembly_contig_chr_name,assembly_contig_chr_start,assembly_contig_type)
);
