-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `misc_set`
--

CREATE TABLE misc_set (
  misc_set_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(25) NOT NULL default '',
  name varchar(255) NOT NULL default '',
  description text NOT NULL,
  max_length int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (misc_set_id),
  UNIQUE KEY c (code)
) TYPE=MyISAM;
