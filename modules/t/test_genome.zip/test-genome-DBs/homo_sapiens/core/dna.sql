# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_30
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'dna'
#

CREATE TABLE dna (
  seq_region_id int(10) unsigned NOT NULL default '0',
  sequence mediumtext collate latin1_bin NOT NULL,
  PRIMARY KEY  (seq_region_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
