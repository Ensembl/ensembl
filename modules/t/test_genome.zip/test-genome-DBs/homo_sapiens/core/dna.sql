# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_core
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dna'
#

CREATE TABLE dna (
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  sequence mediumtext DEFAULT '' NOT NULL,
  PRIMARY KEY (seq_region_id)
);
