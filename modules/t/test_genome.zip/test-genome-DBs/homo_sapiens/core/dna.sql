# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'dna'
#

CREATE TABLE dna (
  dna_id int(10) unsigned NOT NULL auto_increment,
  sequence mediumtext DEFAULT '' NOT NULL,
  created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY (dna_id)
);
