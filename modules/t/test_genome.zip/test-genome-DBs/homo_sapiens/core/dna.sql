-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'dna'
--

CREATE TABLE dna (
  seq_region_id int(10) unsigned NOT NULL default '0',
  sequence mediumtext NOT NULL,
  PRIMARY KEY  (seq_region_id)
) TYPE=MyISAM MAX_ROWS=750000 AVG_ROW_LENGTH=19000;
