# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'translation_attrib'
#

CREATE TABLE translation_attrib (
  translation_id int(10) unsigned DEFAULT '0' NOT NULL,
  attrib_type_id smallint(5) unsigned DEFAULT '0' NOT NULL,
  value varchar(255) DEFAULT '' NOT NULL,
  KEY type_val_idx (attrib_type_id,value),
  KEY translation_idx (translation_id)
);
