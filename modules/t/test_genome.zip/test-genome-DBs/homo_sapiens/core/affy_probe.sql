-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `affy_probe`
--

CREATE TABLE affy_probe (
  affy_probe_id int(11) NOT NULL auto_increment,
  affy_array_id int(11) NOT NULL default '0',
  probeset varchar(40) default NULL,
  name varchar(20) default NULL,
  PRIMARY KEY  (affy_probe_id,affy_array_id),
  KEY probeset_idx (probeset),
  KEY array_idx (affy_array_id)
) TYPE=MyISAM;
