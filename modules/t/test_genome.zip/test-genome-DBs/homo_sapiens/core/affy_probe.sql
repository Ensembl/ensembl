# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'affy_probe'
#

CREATE TABLE affy_probe (
  affy_probe_id int(11) NOT NULL auto_increment,
  affy_array_id int(11) DEFAULT '0' NOT NULL,
  probeset varchar(40),
  name varchar(20),
  PRIMARY KEY (affy_probe_id,affy_array_id),
  KEY probeset_idx (probeset),
  KEY array_idx (affy_array_id)
);
