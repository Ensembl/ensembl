# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'simple_feature'
#

CREATE TABLE simple_feature (
  simple_feature_id int(10) unsigned NOT NULL auto_increment,
  contig_id int(10) unsigned DEFAULT '0' NOT NULL,
  contig_start int(10) unsigned DEFAULT '0' NOT NULL,
  contig_end int(10) unsigned DEFAULT '0' NOT NULL,
  contig_strand tinyint(1) DEFAULT '0' NOT NULL,
  analysis_id int(10) unsigned DEFAULT '0' NOT NULL,
  display_label varchar(40) DEFAULT '' NOT NULL,
  score double,
  PRIMARY KEY (simple_feature_id),
  KEY contig_idx (contig_id,analysis_id,contig_start),
  KEY analysis_idx (analysis_id,contig_id),
  KEY hit_idx (display_label)
);
