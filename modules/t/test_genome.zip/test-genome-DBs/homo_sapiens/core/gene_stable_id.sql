# MySQL dump 8.16
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'gene_stable_id'
#

CREATE TABLE gene_stable_id (
  gene_id int(10) unsigned DEFAULT '0' NOT NULL,
  stable_id varchar(40) DEFAULT '' NOT NULL,
  version int(10),
  created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  modified datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY (gene_id),
  UNIQUE stable_id (stable_id,version)
);
