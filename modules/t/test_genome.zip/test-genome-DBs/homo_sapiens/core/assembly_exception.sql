-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'assembly_exception'
--

CREATE TABLE assembly_exception (
  seq_region_id int(11) default NULL,
  seq_region_start int(11) default NULL,
  seq_region_end int(11) default NULL,
  exc_type enum('HAP','PAR') default NULL,
  exc_seq_region_id int(11) default NULL,
  exc_seq_region_start int(11) default NULL,
  exc_seq_region_end int(11) default NULL,
  ori int(11) default NULL,
  KEY sr_idx (seq_region_id,seq_region_start),
  KEY ex_idx (exc_seq_region_id,exc_seq_region_start)
) TYPE=MyISAM;
