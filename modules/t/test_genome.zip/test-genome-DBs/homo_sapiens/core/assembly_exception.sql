# MySQL dump 8.10
#
# Host: localhost    Database: glenn_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'assembly_exception'
#

CREATE TABLE assembly_exception (
  seq_region_id int(11),
  seq_region_start int(11),
  seq_region_end int(11),
  exc_type enum('HAP','PAR'),
  exc_seq_region_id int(11),
  exc_seq_region_start int(11),
  exc_seq_region_end int(11),
  ori int(11),
  KEY sr_idx (seq_region_id,seq_region_start),
  KEY ex_idx (exc_seq_region_id,exc_seq_region_start)
);
