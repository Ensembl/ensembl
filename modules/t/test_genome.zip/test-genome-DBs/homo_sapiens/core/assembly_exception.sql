# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'assembly_exception'
#

CREATE TABLE assembly_exception (
  assembly_exception_id int(10) unsigned NOT NULL auto_increment,
  seq_region_id int(11) DEFAULT '0' NOT NULL,
  seq_region_start int(11) DEFAULT '0' NOT NULL,
  seq_region_end int(11) DEFAULT '0' NOT NULL,
  exc_type enum('HAP','PAR') DEFAULT 'HAP' NOT NULL,
  exc_seq_region_id int(11) DEFAULT '0' NOT NULL,
  exc_seq_region_start int(11) DEFAULT '0' NOT NULL,
  exc_seq_region_end int(11) DEFAULT '0' NOT NULL,
  ori int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (assembly_exception_id),
  KEY sr_idx (seq_region_id,seq_region_start),
  KEY ex_idx (exc_seq_region_id,exc_seq_region_start)
);
