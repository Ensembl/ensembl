# MySQL dump 8.10
#
# Host: ecs1c    Database: mcvicker_markers_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'marker'
#

CREATE TABLE marker (
  marker_id int(10) unsigned DEFAULT '0' NOT NULL,
  display_marker_synonym_id int(10) unsigned,
  left_primer char(100) DEFAULT '' NOT NULL,
  right_primer char(100) DEFAULT '' NOT NULL,
  min_primer_dist int(10) unsigned DEFAULT '0' NOT NULL,
  max_primer_dist int(10) unsigned DEFAULT '0' NOT NULL,
  priority int(11)
);
