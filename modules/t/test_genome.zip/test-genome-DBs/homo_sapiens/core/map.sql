-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'map'
--

CREATE TABLE map (
  map_id int(10) unsigned NOT NULL auto_increment,
  map_name varchar(30) NOT NULL default '',
  PRIMARY KEY  (map_id)
) TYPE=MyISAM;
