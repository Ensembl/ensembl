# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_28_5_115918
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'map'
#

CREATE TABLE map (
  map_id int(10) unsigned NOT NULL auto_increment,
  map_name varchar(30) DEFAULT '' NOT NULL,
  PRIMARY KEY (map_id)
);
