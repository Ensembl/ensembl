# MySQL dump 8.10
#
# Host: ecs1c    Database: mcvicker_markers_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'map'
#

CREATE TABLE map (
  map_id int(10) unsigned DEFAULT '0' NOT NULL,
  map_name char(30) DEFAULT '' NOT NULL
);
