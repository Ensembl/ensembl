# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'density_feature'
#

CREATE TABLE density_feature (
  density_feature_id int(11) NOT NULL auto_increment,
  density_type_id int(11) DEFAULT '0' NOT NULL,
  seq_region_id int(11) DEFAULT '0' NOT NULL,
  seq_region_start int(11) DEFAULT '0' NOT NULL,
  seq_region_end int(11) DEFAULT '0' NOT NULL,
  density_value float DEFAULT '0' NOT NULL,
  PRIMARY KEY (density_feature_id),
  KEY seq_region_idx (density_type_id,seq_region_id,seq_region_start)
);
