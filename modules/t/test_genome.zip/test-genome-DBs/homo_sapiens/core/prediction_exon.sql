# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'prediction_exon'
#

CREATE TABLE prediction_exon (
  prediction_exon_id int(10) unsigned NOT NULL auto_increment,
  prediction_transcript_id int(10) unsigned DEFAULT '0' NOT NULL,
  exon_rank smallint(5) unsigned DEFAULT '0' NOT NULL,
  seq_region_id int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_start int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_end int(10) unsigned DEFAULT '0' NOT NULL,
  seq_region_strand tinyint(4) DEFAULT '0' NOT NULL,
  start_phase tinyint(4) DEFAULT '0' NOT NULL,
  score double,
  p_value double,
  PRIMARY KEY (prediction_exon_id),
  KEY prediction_transcript_id (prediction_transcript_id),
  KEY seq_region_id (seq_region_id,seq_region_start)
);
