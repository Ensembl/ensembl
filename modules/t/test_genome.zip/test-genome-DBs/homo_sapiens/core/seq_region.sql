-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'seq_region'
--

CREATE TABLE seq_region (
  seq_region_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40) default NULL,
  coord_system_id int(10) default NULL,
  length int(10) default NULL,
  PRIMARY KEY  (seq_region_id),
  UNIQUE KEY coord_system_id (coord_system_id,name)
) TYPE=MyISAM;
