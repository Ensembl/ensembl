# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'seq_region'
#

CREATE TABLE seq_region (
  seq_region_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40),
  coord_system_id int(10),
  length int(10),
  UNIQUE coord_system_id (coord_system_id,name),
  PRIMARY KEY (seq_region_id),
  KEY name_idx (name)
);
