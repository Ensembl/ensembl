# MySQL dump 8.10
#
# Host: ecs1d    Database: alistair_1mb_chr20_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'contig'
#

CREATE TABLE contig (
  contig_id int(10) unsigned NOT NULL auto_increment,
  name varchar(40) DEFAULT '' NOT NULL,
  clone_id int(10) DEFAULT '0' NOT NULL,
  length int(10) unsigned DEFAULT '0' NOT NULL,
  embl_offset int(10) unsigned,
  dna_id int(10) DEFAULT '0' NOT NULL,
  PRIMARY KEY (contig_id),
  UNIQUE name (name),
  KEY clone (clone_id),
  KEY dna (dna_id)
);
