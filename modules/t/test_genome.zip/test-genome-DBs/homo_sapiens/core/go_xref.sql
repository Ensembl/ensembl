# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_2_6_175857
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'go_xref'
#

CREATE TABLE go_xref (
  object_xref_id int(10) unsigned DEFAULT '0' NOT NULL,
  linkage_type enum('computational','experimental','curated'),
  PRIMARY KEY (object_xref_id)
);
