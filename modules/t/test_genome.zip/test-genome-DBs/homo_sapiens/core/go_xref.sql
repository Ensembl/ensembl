# MySQL dump 8.16
#
# Host: ecs4    Database: _test_db_homo_sapiens_core_gp1_23_3_10017
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'go_xref'
#

CREATE TABLE go_xref (
  object_xref_id int(10) unsigned NOT NULL default '0',
  linkage_type enum('IC','IDA','IEA','IEP','IGI','IMP','IPI','ISS','NAS','ND','TAS','NR') collate latin1_bin NOT NULL default 'IC',
  UNIQUE KEY object_xref_id_2 (object_xref_id,linkage_type),
  KEY object_xref_id (object_xref_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
