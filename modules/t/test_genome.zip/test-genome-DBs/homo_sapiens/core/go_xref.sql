# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'go_xref'
#

CREATE TABLE go_xref (
  object_xref_id int(10) unsigned DEFAULT '0' NOT NULL,
  linkage_type enum('IC','IDA','IEA','IEP','IGI','IMP','IPI','ISS','NAS','ND','TAS','NR') DEFAULT 'IC' NOT NULL,
  KEY object_xref_id (object_xref_id),
  UNIQUE object_xref_id_2 (object_xref_id,linkage_type)
);
