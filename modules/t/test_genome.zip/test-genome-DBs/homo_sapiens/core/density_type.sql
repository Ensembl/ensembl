# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'density_type'
#

CREATE TABLE density_type (
  density_type_id int(11) NOT NULL auto_increment,
  analysis_id int(11) DEFAULT '0' NOT NULL,
  block_size int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (density_type_id),
  KEY analysis_idx (analysis_id,block_size)
);
