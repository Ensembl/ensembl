CREATE TABLE qtl_feature (
  chromosome_id int not null,
  start int not null,
  end int not null,
  qtl_id int not null,
  analysis_id int not null,
  key( qtl_id ),
  key loc_idx( chromosome_id, start )
);

