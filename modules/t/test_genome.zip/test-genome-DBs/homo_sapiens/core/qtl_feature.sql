# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_2_6_175857
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'qtl_feature'
#

CREATE TABLE qtl_feature (
  chromosome_id int(11) DEFAULT '0' NOT NULL,
  start int(11) DEFAULT '0' NOT NULL,
  end int(11) DEFAULT '0' NOT NULL,
  qtl_id int(11) DEFAULT '0' NOT NULL,
  analysis_id int(11) DEFAULT '0' NOT NULL,
  KEY qtl_id (qtl_id),
  KEY loc_idx (chromosome_id,start)
);
