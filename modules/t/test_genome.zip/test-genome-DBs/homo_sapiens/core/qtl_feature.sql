# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'qtl_feature'
#

CREATE TABLE qtl_feature (
  seq_region_id int(11) DEFAULT '0' NOT NULL,
  seq_region_start int(11) DEFAULT '0' NOT NULL,
  seq_region_end int(11) DEFAULT '0' NOT NULL,
  qtl_id int(11) DEFAULT '0' NOT NULL,
  analysis_id int(11) DEFAULT '0' NOT NULL,
  KEY qtl_id (qtl_id),
  KEY loc_idx (seq_region_id,seq_region_start)
);
