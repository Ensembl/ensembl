# MySQL dump 8.10
#
# Host: ecs1c    Database: _test_db_homo_sapiens_core_stabenau_28_5_115918
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'chromosome'
#

CREATE TABLE chromosome (
  chromosome_id tinyint(3) unsigned DEFAULT '0' NOT NULL,
  name char(40) DEFAULT '' NOT NULL,
  known_genes int(11),
  unknown_genes int(11),
  snps int(11),
  length int(11)
);
