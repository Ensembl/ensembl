# MySQL dump 8.16
#
# Host: ecs4    Database: _test_db_homo_sapiens_core_gp1_23_3_10017
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'regulatory_motif'
#

CREATE TABLE regulatory_motif (
  regulatory_motif_id int(11) NOT NULL auto_increment,
  name varchar(255) collate latin1_bin NOT NULL default '',
  `type` enum('miRNA_target','promoter') collate latin1_bin default NULL,
  PRIMARY KEY  (regulatory_motif_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
