-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'attrib_type'
--

CREATE TABLE attrib_type (
  attrib_type_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(15) NOT NULL default '',
  name varchar(255) NOT NULL default '',
  description text NOT NULL,
  PRIMARY KEY  (attrib_type_id),
  UNIQUE KEY c (code)
) TYPE=MyISAM;
