# MySQL dump 8.16
#
# Host: ecs1d    Database: mcvicker_test_core
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'attrib_type'
#

CREATE TABLE attrib_type (
  attrib_type_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(15) DEFAULT '' NOT NULL,
  name varchar(255) DEFAULT '' NOT NULL,
  description text,
  PRIMARY KEY (attrib_type_id),
  UNIQUE c (code)
);
