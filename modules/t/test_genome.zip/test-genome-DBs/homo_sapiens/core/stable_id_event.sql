# MySQL dump 8.10
#
# Host: localhost    Database: glenn_new_schema
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'stable_id_event'
#

CREATE TABLE stable_id_event (
  old_stable_id varchar(40),
  old_version smallint(6),
  new_stable_id varchar(40),
  new_version smallint(6),
  mapping_session_id int(11) DEFAULT '0' NOT NULL,
  type enum('gene','transcript','translation') DEFAULT 'gene' NOT NULL,
  UNIQUE tpl_idx (old_stable_id,new_stable_id,mapping_session_id),
  KEY new_idx (new_stable_id)
);
