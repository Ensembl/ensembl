-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'stable_id_event'
--

CREATE TABLE stable_id_event (
  old_stable_id varchar(40) default NULL,
  old_version smallint(6) default NULL,
  new_stable_id varchar(40) default NULL,
  new_version smallint(6) default NULL,
  mapping_session_id int(11) NOT NULL default '0',
  type enum('gene','transcript','translation') NOT NULL default 'gene',
  UNIQUE KEY tpl_idx (old_stable_id,new_stable_id,mapping_session_id),
  KEY new_idx (new_stable_id)
) TYPE=MyISAM;
