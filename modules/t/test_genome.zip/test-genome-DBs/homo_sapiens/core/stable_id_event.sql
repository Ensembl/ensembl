# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'stable_id_event'
#

CREATE TABLE stable_id_event (
  old_stable_id varchar(128),
  old_version smallint(6),
  new_stable_id varchar(128),
  new_version smallint(6),
  mapping_session_id int(11) DEFAULT '0' NOT NULL,
  type enum('gene','transcript','translation') DEFAULT 'gene' NOT NULL,
  UNIQUE uni_idx (mapping_session_id,old_stable_id,old_version,new_stable_id,new_version,type),
  KEY new_idx (new_stable_id),
  KEY old_idx (old_stable_id)
);
