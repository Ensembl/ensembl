# MySQL dump 8.16
#
# Host: ecs4    Database: _test_db_homo_sapiens_core_gp1_23_3_10017
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'supporting_feature'
#

CREATE TABLE supporting_feature (
  exon_id int(11) NOT NULL default '0',
  feature_type enum('dna_align_feature','protein_align_feature') collate latin1_bin default NULL,
  feature_id int(11) NOT NULL default '0',
  UNIQUE KEY all_idx (exon_id,feature_type,feature_id),
  KEY feature_idx (feature_type,feature_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
