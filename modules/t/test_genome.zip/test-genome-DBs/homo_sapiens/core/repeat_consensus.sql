# MySQL dump 8.10
#
# Host: ecs1c    Database: arne_new_test
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'repeat_consensus'
#

CREATE TABLE repeat_consensus (
  repeat_consensus_id int(10) unsigned NOT NULL auto_increment,
  repeat_name varchar(255) DEFAULT '' NOT NULL,
  repeat_class varchar(40) DEFAULT '' NOT NULL,
  repeat_consensus text,
  PRIMARY KEY (repeat_consensus_id),
  KEY name (repeat_name),
  KEY class (repeat_class),
  KEY consensus (repeat_consensus(10))
);
