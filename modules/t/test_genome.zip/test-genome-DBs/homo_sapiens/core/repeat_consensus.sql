-- MySQL dump 8.21
--
-- Host: localhost    Database: test_ensembl
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'repeat_consensus'
--

CREATE TABLE repeat_consensus (
  repeat_consensus_id int(10) unsigned NOT NULL auto_increment,
  repeat_name varchar(255) NOT NULL default '',
  repeat_class varchar(40) NOT NULL default '',
  repeat_consensus text,
  PRIMARY KEY  (repeat_consensus_id),
  KEY name (repeat_name),
  KEY class (repeat_class),
  KEY consensus (repeat_consensus(10))
) TYPE=MyISAM;
