# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_test_27
#--------------------------------------------------------
# Server version	3.23.25-beta

#
# Table structure for table 'alt_allele'
#

CREATE TABLE alt_allele (
  alt_allele_id int(11) NOT NULL auto_increment,
  gene_id int(11) DEFAULT '0' NOT NULL,
  UNIQUE gene_idx (gene_id),
  UNIQUE allele_idx (alt_allele_id,gene_id)
);
