# MySQL dump 8.16
#
# Host: ecs1c    Database: stabenau_ens36_map
#--------------------------------------------------------
# Server version	4.1.12-log

#
# Table structure for table 'alt_allele'
#

CREATE TABLE alt_allele (
  alt_allele_id int(11) NOT NULL auto_increment,
  gene_id int(11) NOT NULL default '0',
  UNIQUE KEY gene_idx (gene_id),
  UNIQUE KEY allele_idx (alt_allele_id,gene_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
