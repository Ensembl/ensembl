-- MySQL dump 9.11
--
-- Host: localhost    Database: arne_ens_test
-- ------------------------------------------------------
-- Server version	4.0.20-standard

--
-- Table structure for table `alt_allele`
--

CREATE TABLE alt_allele (
  alt_allele_id int(11) NOT NULL auto_increment,
  gene_id int(11) NOT NULL default '0',
  UNIQUE KEY gene_idx (gene_id),
  UNIQUE KEY allele_idx (alt_allele_id,gene_id)
) TYPE=MyISAM;
