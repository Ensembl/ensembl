CREATE TABLE alt_allele (
  alt_allele_id INT NOT NULL auto_increment,
  gene_id INT NOT NULL,

  UNIQUE gene_idx( gene_id ),
  UNIQUE allele_idx( alt_allele_id, gene_id )
);
 
