# MySQL dump 8.16
#
# Host: ecs4    Database: _test_db_homo_sapiens_core_gp1_23_3_10017
#--------------------------------------------------------
# Server version	4.1.10-standard-log

#
# Table structure for table 'mapping_session'
#

CREATE TABLE mapping_session (
  mapping_session_id int(11) NOT NULL auto_increment,
  old_db_name varchar(80) collate latin1_bin NOT NULL default '',
  new_db_name varchar(80) collate latin1_bin NOT NULL default '',
  created timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (mapping_session_id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;
